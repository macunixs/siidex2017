from time import sleep
from gpiozero import Buzzer,LED
import picamera 
from datetime import datetime,timedelta

bz = Buzzer(17)
led = LED(26)

def wait():
    #calculate the delay to the start of the next hour
    bz.off()
    print('entering wait function')
    next_hour = (datetime.now()+ timedelta(seconds=10))
    print("next_hour:{}".format(next_hour))
    delay = (next_hour - datetime.now()).seconds
    print("delay:{}".format(delay))
    led.on()
    sleep(delay)
    led.off()
    print('delay={}'.format(delay))


with picamera.PiCamera() as camera: 
    camera.resolution = (640,320)
    wait()
    for filename in camera.capture_continuous('IMG {timestamp:%Y-%m-%d-%H-%M-%s}.jpg'):
        print('>>>Captured %s ' % filename)
        bz.on()
        sleep(1)
        wait()
