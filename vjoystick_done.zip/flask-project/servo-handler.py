from gpiozero import Servo
from time import sleep

tilt = Servo(23)
pan = Servo(24)
try:
    while True:
        # panning movement only
        tilt.mid()
        pan.mid()
        sleep(5)
        tilt.mid()
        pan.min()
        sleep(5)
        tilt.mid()
        pan.mid()
        sleep(5)
        tilt.mid()
        pan.max()
        sleep(5)
        # tilting movement only
        tilt.mid()
        pan.mid()
        sleep(5)
        # looking down a little longer to see LEDs
        tilt.max()
        pan.mid()
        sleep(10)
        tilt.mid()
        pan.mid()
        sleep(5)
        tilt.min()
        pan.mid()
        sleep(5)

except KeyboardInterrupt:
    tilt.mid()
    pan.mid()
    sleep(2)
    tilt.detach()
    pan.detach()