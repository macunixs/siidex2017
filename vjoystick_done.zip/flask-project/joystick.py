from gpiozero import Servo
from flask import Flask,render_template,request
from time import sleep
from flask_socketio import SocketIO
import math
from gpiozero import OutputDevice,PWMOutputDevice

global direction
global planar

speedL = PWMOutputDevice(13)
speedR = PWMOutputDevice(21)
in3 = OutputDevice(20)
in4 = OutputDevice(16)
in1 = OutputDevice(19)
in2 = OutputDevice(26)

def goRight():
    in1.on()
    in2.off()
    in3.off()
    in4.on()

def goLeft():
    in1.off()
    in2.on()
    in3.on()
    in4.off()

def goBackward():
    in1.off()
    in2.on()
    in3.off()
    in4.on()

def goForward():
    in1.on()
    in2.off()
    in3.on()
    in4.off()

def stop():
    in1.off()
    in2.off()
    in3.off()
    in4.off()

app = Flask(__name__)
socketio =SocketIO(app)
@app.route("/")
def index():
    return render_template('joystick.html')

@socketio.on('touchevent')
def get_event(event):
    print("Touch has {}ed".format(event))

@socketio.on('direction')
def get_direction(dir):
    global direction
    direction = dir
    #dir = dir.strip('dir:')
    #print("direction:{}".format(dir))

@socketio.on('plane')
def get_plane(plane):
    global planar
    planar = plane
    print("plane:{}".format(plane))


@socketio.on('touchcount')
def touch_count(count):
    print("touch event count is:{}".format(count))

@socketio.on('get_data')
def retrieve_data(force,distance,degree):
#    print("force:{:.2f} distance:{:.2f} degree:{:2f}".format(force,distance,degree))
    global direction
    global planar
    slow = 0.1
    speed = round(distance,2)/100

    if planar == "plain:up":
        goForward()
    if planar == "plain:down":
        goBackward()

    if direction == "dir:right":
        speedR.value = slow*speed
        speedL.value = speed 
    elif direction == "dir:left":
        speedL.value = slow*speed
        speedR.value = speed
    else:
        speedL.value = speed 
        speedR.value = speed 
    print("speedL:{} speedR:{}".format(speedL.value,speedR.value))
    print("Direction GLOBAL:{}".format(direction))
if __name__ == "__main__":
    socketio.run(app,host='0.0.0.0',port=5000,debug=False)
