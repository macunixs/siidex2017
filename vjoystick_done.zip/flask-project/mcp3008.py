#mcp3008 tester
from gpiozero import MCP3008
from time import sleep

ldr = MCP3008(1) # LDR is connected to CH1
temp35 = MCP3008(2) #LM35
ntc1 = MCP3008(5)
ntc2 = MCP3008(6)

try:
    while True:
        read_ldr = ldr.raw_value
        t35 = 0.322*temp35.raw_value 
        ntc1_temp = ntc1.raw_value / 18
        ntc2_temp = ntc2.raw_value / 18
        print("ldr:{} temp:{} ntcw:{} ntcb:{}".format(int(read_ldr),int(t35),int(ntc1_temp),int(ntc2_temp)))
        sleep(1)
except KeyboardInterrupt:
    print