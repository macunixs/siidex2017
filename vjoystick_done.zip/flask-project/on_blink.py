from gpiozero import LED
from time import sleep

blue_led = LED(19)

while True:
    blue_led.on()
    sleep(0.05)
    blue_led.off()
    sleep(0.1)
    
    blue_led.on()
    sleep(0.05)
    blue_led.off()
    sleep(1)