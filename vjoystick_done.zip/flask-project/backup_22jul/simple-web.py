from gpiozero import MCP3008,LED,RGBLED,DistanceSensor,Servo
from time import sleep 
import threading

from flask import *
from flask_socketio import SocketIO

led = LED(21)

read_ldr = 0
read_pot = 0
t35 = 0

app = Flask(__name__)
socketio = SocketIO(app)
@app.route("/")
def index():
    return render_template('home.html')

@socketio.on('setred')
def set_red(state):
    print("Red LED: {}")

@socketio.on('setgreen')
def set_green(state):
    print("Green LED: {}")

@socketio.on('setblue')
def set_blue(state):
    print("Blue LED: {}")


# Thread for handling MCP3008 data stream
class readMCP3008(threading.Thread):
 
    def __init__(self):
        super(readMCP3008, self).__init__()
        self.terminated = False
        self.start()
 
    def run(self):
        global read_pot
        global read_ldr
        global t35
      
        print '\nMCP3008 started! Reading input channels....'
        while not self.terminated:
            read_pot+=1
            read_ldr+=1
            t35+=1
            led.on()
            socketio.emit('pot', read_pot)
            socketio.emit('ldr', read_ldr)
            socketio.emit('t35', t35)
            sleep(1)
            led.off()
            
            if self.terminated:
	        break
        print 'MCP3008 stopped'

if __name__ == "__main__":
    try:
        # Startup sequence
        print 'start threaddddddd'

        readMCP3008 = readMCP3008()
        socketio.run(app,host='0.0.0.0', port=80, debug=True)

        while True:
            print("\nPot:{:.2f} LDR:{:.2f} LM35:{}C ".format(read_pot,read_ldr,t35))
            sleep(1)
         
    except KeyboardInterrupt:
            print '\nShutting down...'
    readMCP3008.terminated = True
    readMCP3008.join()
    
    print
  
