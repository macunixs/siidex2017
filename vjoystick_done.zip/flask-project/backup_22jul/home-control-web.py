from gpiozero import MCP3008,LED,RGBLED,DistanceSensor,Servo,Buzzer,MotionSensor,CPUTemperature
from gpiozero import OutputDevice
from time import sleep 
import threading

from flask import Flask,render_template,request
from flask_socketio import SocketIO

PORT_NUM = 5000

app = Flask(__name__)
socketio = SocketIO(app)

@app.route("/",methods = ['POST','GET'])
##@app.route("/")
def index():
       
        if request.method == 'POST':
            if request.form['submit'] == 'redon':
                rgb.color = (0,1,1)
            elif request.form['submit'] == 'greenon':
                rgb.color = (1,0,1)
            elif request.form['submit'] == 'blueon':
                rgb.color = (1,1,0)
            elif request.form['submit'] == 'rgboff':
                rgb.color = (1,1,1)
            elif request.form['submit'] == 'center':
                tilt.mid()
                pan.mid()
        return render_template('home.html')
    
##@socketio.on('sbright')
##def set_super(state):
##    if state == 1:
##        sbright.on()
##    if state == 0:
##        sbright.off()
##    
##@socketio.on('setred')
##def set_red(state):
##    if state == 1:
##        rgb.color = (0,1,1)
##    if state == 0:
##        rgb.on()
##
##    print("Red LED: {}".format(rgb.value))
##
##@socketio.on('setgreen')
##def set_green(state):
##    if state == 1:
##        rgb.color = (1,0,1)
##    if state == 0:
##        rgb.on()
##
##    print("Green LED: {}".format(rgb.value))
##
##@socketio.on('setblue')
##def set_blue(state):
##    if state == 1:
##        rgb.color = (1,1,0)
##    if state == 0:
##        rgb.on()
##
##    print("Blue LED: {}".format(rgb.value))

sbright = OutputDevice(27)
cputemp = CPUTemperature()
pir = MotionSensor(4)
bz = Buzzer(17)
servo = Servo(12)
rgb = RGBLED(16,20,21)
hcsr = DistanceSensor(echo=6,trigger=5)
pot = MCP3008(0) # Pot is connected to CH0 
ldr = MCP3008(1) # LDR is connected to CH1
temp35 = MCP3008(2) #LM35
temp2 = MCP3008(3)
temp3 = MCP3008(4)
ntc1 = MCP3008(5)
ntc2 = MCP3008(6)
led = LED(26) 
thresh = 300 # set threshold level

### Thread for servo data stream
##class servoControl(threading.Thread):
## 
##    def __init__(self):
##        super(servoControl, self).__init__()
##        self.terminated = False
##        self.start()
## 
##    def run(self):
##                
##        print ('\n servo thread started! ')
##        while not self.terminated:
##            # panning movement only
##            tilt.mid()
##            pan.mid()
##            sleep(10)
##            tilt.mid()
##            pan.min()
##            sleep(10)
##            tilt.mid()
##            pan.mid()
##            sleep(10)
##            tilt.mid()
##            pan.max()
##            sleep(10)
##            # tilting movement only
##            tilt.mid()
##            pan.mid()
##            sleep(10)
##            tilt.max()
##            pan.mid()
##            sleep(10)
##            tilt.mid()
##            pan.mid()
##            sleep(10)
##            tilt.min()
##            pan.mid()
##            sleep(10)
##
##            if self.terminated:
##	        break
##        print 'servo control stopped'
##
##
##
# Thread for handling HC-SR04 data stream
class cpuSensor(threading.Thread):
 
    def __init__(self):
        super(cpuSensor, self).__init__()
        self.terminated = False
        self.start()
 
    def run(self):
                
        print ('\n CPU sensor thread started! ')
        while not self.terminated:
            cpusuhu = cputemp.value * 100
##            print('cpu temp:{}'.format(cpusuhu))
            sleep(5)
            socketio.emit('cputemp', int(cpusuhu))
        
            if self.terminated:
	        break
        print 'CPU Sensor stopped'



# Thread for handling MCP3008 data stream
class readMCP3008(threading.Thread):
 
    def __init__(self):
        super(readMCP3008, self).__init__()
        self.terminated = False
        self.start()
 
    def run(self):
        global read_pot
        global read_ldr
        global t35
        global T1
        global T2
        global ntc1_temp
        global ntc2_temp
      
        print '\nMCP3008 thread started! Reading input channels....'
        while not self.terminated:
            # grab all available input from 
            # MCP3008
            read_pot = pot.raw_value
            read_ldr = ldr.raw_value

            t35 = 0.322*temp35.raw_value 
            T1 = 15 * temp2.raw_value - 2048 
            T2 = 15 * temp3.raw_value - 2048
            T1 = T1/100
            T2 = T2/100
            ntc1_temp = ntc1.raw_value / 18
            ntc2_temp = ntc2.raw_value / 18
            socketio.emit('pot', int(read_pot))
            socketio.emit('ldr', int(read_ldr))
            socketio.emit('t35', int(t35))
	    socketio.emit('t1',int(T1))
	    socketio.emit('t2',int(T2))
	    socketio.emit('ntc1',ntc1_temp)
	    socketio.emit('ntc2',ntc2_temp)

            if read_ldr < thresh:
                sbright.on()    
            else:
                sbright.off()
            
            
            if ntc1_temp > 35:
                bz.on()
            else:
                bz.off()
            
            sleep(1)
            
            if self.terminated:
	        break
        print '10-bit ADC MCP3008 stopped'

# Thread for handling HC-SR04 data stream
class distance(threading.Thread):
 
    def __init__(self):
        super(distance, self).__init__()
        self.terminated = False
        self.start()
 
    def run(self):
        global dist
        
        print ('\n HCSR04 thread started! ')
        while not self.terminated:
            # grab input from 
            # HCSR04
            dist = hcsr.distance * 100
            sleep(10)
            socketio.emit('dist', int(dist))
            
	
            if self.terminated:
	        break
        print 'HC-SR04 Distance Sensor stopped'

# Thread for handling PIR data stream
class motion(threading.Thread):
 
    def __init__(self):
        super(motion, self).__init__()
        self.terminated = False
        self.start()
 
    def run(self):
    
        
        print ('\n PIR thread started! ')
        while not self.terminated:
##            if pir.motio_detected:
##                print('motion detected!')
##                socketio.emit('motion', pir.motion_detected)
##            else:
##                print('no movement')
##                socketio.emit('motion', pir.motion_detected)        
            socketio.emit('motion', pir.motion_detected)
            if pir.motion_detected:
                led.on()
            else:
                led.off()
            sleep(10)
            
            if self.terminated:
	        break
        print 'Motion Sensor stopped'
        
if __name__ == "__main__":
    try:
        # Startup sequence
        print 'Initialize all threads!!!!!'

        readMCP3008 = readMCP3008()
        sleep(2)
        distance = distance()
        sleep(2)
        motion = motion()
        sleep(2)
        cpuSensor = cpuSensor()
        sleep(2)
       
        rgb.on() # make sure the RGB is turned off
        print 'Press CTRL+C to quit'
        
        print("\nStarting web application at port:{}\n\n".format(PORT_NUM))
        socketio.run(app,host='0.0.0.0', port=PORT_NUM, debug=True)
        running = True
        
        while running:
            sleep(2) # <-- must have something here to make Pi happy =)
    except KeyboardInterrupt:
            print '\nShutting down...'
    readMCP3008.terminated = True
    readMCP3008.join()
    distance.terminated = True
    distance.join()
    motion.terminated = True
    motion.join()
    cpuSensor.terminated = True
    cpuSensor.join()

    
    print
  
