from gpiozero import Servo
from time import sleep

tilt = Servo(23)
pan = Servo(24)

while True:
	tilt.mid()
	pan.mid()
	sleep(1)
	tilt.max()
	pan.max()
	sleep(1)
	tilt.mid()
	pan.mid()
	sleep(1)
	tilt.min()
	pan.min()
	sleep(1)
