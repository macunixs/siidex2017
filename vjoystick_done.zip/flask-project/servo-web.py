from gpiozero import Servo
from flask import Flask,render_template,request
from time import sleep


tilt = Servo(23)
pan = Servo(24)

app = Flask(__name__)

@app.route("/",methods = ['POST','GET'])
def index():
    if request.method == 'POST':

        # if we press the turn on button
        if request.form['submit'] == 'up':
            tilt.min()
            pan.mid()
            sleep(5)
                     
        elif request.form['submit'] == 'down':
            tilt.max()
            pan.mid()
            sleep(5)
        elif request.form['submit'] == 'center':
            tilt.mid()
            pan.mid()
            sleep(5)
        elif request.form['submit'] == 'left':
            tilt.mid()
            pan.min()
            sleep(5)
                
        elif request.form['submit'] == 'right':
            tilt.mid()
            pan.max()
            sleep(5)
        
           
    return render_template('servo.html')

if __name__ == "__main__":
    app.run(host='0.0.0.0',port=5000,debug=True)