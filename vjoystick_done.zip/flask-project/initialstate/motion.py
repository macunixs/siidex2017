from gpiozero import LED,MotionSensor
from time import sleep
from ISStreamer.Streamer import Streamer

motion = MotionSensor(4)


# Initial State bucket name (displayed)
BUCKET_NAME = ":wave: Motion Sensor"
# Initial State bucket key (hidden)
BUCKET_KEY = "pi3wmotion"
# Initial State access key
ACCESS_KEY = 'VZYQQJ3iiVJxWw0aeX7IooXd6IIsHQUm'
# Variables that ensure we don't stream "Motion 
# Detected" or "No Motion" twice in a row This saves 
# on sent events and processing power
alreadyRecordedMotion = False
alreadyRecordedNoMotion = False
# Initialize the Initial State Streamer
streamer = Streamer(bucket_name=BUCKET_NAME, bucket_key=BUCKET_KEY, access_key=ACCESS_KEY)

# Loop indefinitely
while True:
    # If the motion sensor pulls high (detects 
    # motion):
    if motion.motion_detected:
        print "Motion detected"
        # If we haven't streamed yet:
        if not alreadyRecordedMotion:
            # Stream to Initial State
            streamer.log(":spy: Anybody Around?",":runner: Intruder Detected")
            streamer.flush()
            alreadyRecordedMotion = True
            alreadyRecordedNoMotion = False
        else:
            # Pause the script for 1 
            # second
            sleep(1)
    else:
        print "No motion detected"
        # If we haven't streamed yet:
        if not alreadyRecordedNoMotion:
            # Stream to Initial State
            streamer.log(":spy: Anybody Around?",":no_pedestrians: Safe")
            streamer.flush()
            alreadyRecordedNoMotion = True
            alreadyRecordedMotion = False
        else:
            # Pause the script for 1 
            # second
            sleep(1)
